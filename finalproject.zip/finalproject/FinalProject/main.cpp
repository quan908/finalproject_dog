#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "imgui.h"
#include "imgui_impl_glfw.h"
#include "imgui_impl_opengl3.h"

#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>
#include "SoundManager.hpp"

#include <iostream>
#include <vector>

using namespace XQ;
using namespace std;

// --- 1. GameObject �ṹ�� (�������߱�) ---
struct GameObject {
    glm::vec3 position;
    float size;
    unsigned int textureID;
    bool isVisible;
    float aspectRatio; // ���ڴ洢���߱�

    // AABB ��ײ�� (���ǿ��߱ȣ�����ȷ)
    glm::vec2 getMin() const {
        return glm::vec2(position.x - size * aspectRatio * 0.5f, position.y - size * 0.5f);
    }
    glm::vec2 getMax() const {
        return glm::vec2(position.x + size * aspectRatio * 0.5f, position.y + size * 0.5f);
    }
};

// --- 2. ��ײ��⺯�� ---
bool checkCollision(const GameObject& one, const GameObject& two) {
    glm::vec2 oneMin = one.getMin();
    glm::vec2 oneMax = one.getMax();
    glm::vec2 twoMin = two.getMin();
    glm::vec2 twoMax = two.getMax();

    bool collisionX = oneMax.x >= twoMin.x && twoMax.x >= oneMin.x;
    bool collisionY = oneMax.y >= twoMin.y && twoMax.y >= oneMin.y;
    return collisionX && collisionY;
}

// --- 3. ������Ϣ�ṹ��ͼ��غ��� (����ID�Ϳ��߱�) ---
struct TextureInfo {
    unsigned int id;
    float aspectRatio;
};

TextureInfo loadTexture(const char* path) {
    TextureInfo texInfo = { 0, 1.0f }; // Ĭ��ֵ

    int width, height, nrComponents;
    unsigned char* data = stbi_load(path, &width, &height, &nrComponents, 0);
    if (data) {
        if (height > 0) {
            texInfo.aspectRatio = (float)width / (float)height;
        }

        GLenum format = GL_RGBA;
        if (nrComponents == 1) format = GL_RED;
        else if (nrComponents == 3) format = GL_RGB;
        else if (nrComponents == 4) format = GL_RGBA;

        glGenTextures(1, &texInfo.id);
        glBindTexture(GL_TEXTURE_2D, texInfo.id);
        glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
        glGenerateMipmap(GL_TEXTURE_2D);

        // ʹ����ȷ�Ļ���ģʽ����ֹ��Ե�ظ�/�������
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        stbi_image_free(data);
    }
    else {
        std::cout << "Texture failed to load at path: " << path << std::endl;
    }
    return texInfo;
}

// (��ɫ������ͱ��뺯�����ֲ���)
const char* vertexShaderSource = R"(
#version 330 core
layout (location=0) in vec3 aPos;
layout (location=1) in vec3 aColor;
layout (location=2) in vec2 atexCoord;
layout (location=3) in vec3 aNormal;

out vec3 vertexColor;
out vec2 texCoord;
out vec3 normal;
out vec3 fragPos;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
  vec4 worldPos = model * vec4(aPos, 1.0);
  fragPos = vec3(worldPos);
  gl_Position = projection * view * worldPos;
  vertexColor = aColor;
  texCoord = atexCoord;
  normal = normalize(aNormal);
}
)";

const char* fragmentShaderSource = R"(
#version 330 core
in vec3 vertexColor;
in vec2 texCoord;
in vec3 normal;
in vec3 fragPos;

out vec4 FragColor;

uniform sampler2D mytexture;
uniform float ambientIntensity;
uniform vec3 lightPos;

void main()
{
  vec3 lightColor = vec3(1.0, 1.0, 1.0);
  vec3 lightDirection = normalize(lightPos - fragPos);
  float diff = max(dot(normal, lightDirection), 0.0);
  vec3 diffLight = diff * lightColor;
  vec3 ambientLight = ambientIntensity * lightColor;
  vec3 finalLight = ambientLight + diffLight;
  FragColor = vec4(finalLight, 1.0) * texture(mytexture, texCoord);
}
)";

unsigned int compileShader(unsigned int type, const char* source) {
    unsigned int shader_id = glCreateShader(type);
    glShaderSource(shader_id, 1, &source, NULL);
    glCompileShader(shader_id);
    int success;
    char infoLog[512];
    glGetShaderiv(shader_id, GL_COMPILE_STATUS, &success);
    if (!success) {
        glGetShaderInfoLog(shader_id, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::COMPILATION_FAILED\n" << infoLog << std::endl;
    }
    return shader_id;
}

unsigned int createShaderProgram() {
    unsigned int vertexShader_id = compileShader(GL_VERTEX_SHADER, vertexShaderSource);
    unsigned int fragmentShader_id = compileShader(GL_FRAGMENT_SHADER, fragmentShaderSource);
    unsigned int shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader_id);
    glAttachShader(shaderProgram, fragmentShader_id);
    glLinkProgram(shaderProgram);
    glDeleteShader(vertexShader_id);
    glDeleteShader(fragmentShader_id);
    return shaderProgram;
}


int main(void) {
    // --- ��ʼ�����ں�ϵͳ ---
    if (!glfwInit()) {
        cout << "Failed to initialize GLFW" << endl;
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    GLFWwindow* window = glfwCreateWindow(800, 600, "Dog Eats Cookies - Final", NULL, NULL);
    if (!window) {
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    if (glewInit() != GLEW_OK) {
        cout << "Failed to initialize GLEW" << endl;
        return -1;
    }

    // --- ��ʼ������������������BGM ---
    XQ::SoundManager soundManager;
    if (soundManager.init() < 0) {
        std::cout << "sound init is unsuccessful";
        return -1;
    }
    soundManager.playMusic("assets/bgmusic.mp3");

    // --- ����OpenGL״̬ ---
    glViewport(0, 0, 800, 600);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // --- ����������ͼ ---
    stbi_set_flip_vertically_on_load(true);
    TextureInfo dogTextureInfo = loadTexture("assets/dog.png");
    TextureInfo cookieTextureInfo = loadTexture("assets/cookie.png");
    TextureInfo bgTextureInfo = loadTexture("assets/bg.png");

    // --- ������������ (VAO/VBO/EBO) ---
    float vertices[] = {
        // positions      // colors        // texture coords // normals
         0.5f,  0.5f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f,   0.0f, 0.0f, 1.0f,
         0.5f, -0.5f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f,   0.0f, 0.0f, 1.0f,
        -0.5f, -0.5f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f,   0.0f, 0.0f, 1.0f,
        -0.5f,  0.5f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f, 1.0f,   0.0f, 0.0f, 1.0f
    };
    unsigned int indices[] = { 0, 1, 3, 1, 2, 3 };
    unsigned int VAO, VBO, EBO;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(float), (void*)(8 * sizeof(float)));
    glEnableVertexAttribArray(3);
    glBindVertexArray(0);

    // --- ������ɫ������ ---
    unsigned int shaderProgram = createShaderProgram();

    // --- ������Ϸ����ʵ�� ---
    GameObject dog = { glm::vec3(0.0f), 1.5f, dogTextureInfo.id, true, dogTextureInfo.aspectRatio };
    vector<GameObject> cookies;
    cookies.push_back({ glm::vec3(2.5f, 2.0f, 0.0f), 0.5f, cookieTextureInfo.id, true, cookieTextureInfo.aspectRatio });
    cookies.push_back({ glm::vec3(-2.0f, -1.5f, 0.0f), 0.5f, cookieTextureInfo.id, true, cookieTextureInfo.aspectRatio });
    cookies.push_back({ glm::vec3(1.5f, -2.5f, 0.0f), 0.5f, cookieTextureInfo.id, true, cookieTextureInfo.aspectRatio });
    GameObject background = { glm::vec3(0.0f, 0.0f, -5.0f), 10.0f, bgTextureInfo.id, true, bgTextureInfo.aspectRatio };

    // --- ��ʼ�� ImGui ---
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init();

    // --- �������� ---
    glm::vec3 cam_position(0.0f, 0.0f, 8.0f);
    glm::vec3 cam_center(0.0f, 0.0f, 0.0f);
    float ambientIntensity = 0.8f;
    glm::vec3 lightPos(0.0f, 0.0f, 10.0f);

    // --- ��ѭ�� ---
    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();

        // ��Ϸ�߼����� (��ײ���)
        for (auto& cookie : cookies) {
            if (cookie.isVisible && checkCollision(dog, cookie)) {
                cookie.isVisible = false;
                soundManager.playSoundEffect("assets/eat_sound.wav");
            }
        }

        // ��Ⱦ
        glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glUseProgram(shaderProgram);
        glBindVertexArray(VAO);

        // ����ͳһ����ͼ��ͶӰ����
        glm::mat4 view = glm::lookAt(cam_position, cam_center, glm::vec3(0.0f, 1.0f, 0.0f));
        glm::mat4 projection = glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
        glUniform1f(glGetUniformLocation(shaderProgram, "ambientIntensity"), ambientIntensity);
        glUniform3fv(glGetUniformLocation(shaderProgram, "lightPos"), 1, glm::value_ptr(lightPos));
        glUniform1i(glGetUniformLocation(shaderProgram, "mytexture"), 0);

        // ��װһ����Ⱦ��������������ظ�
        auto renderObject = [&](const GameObject& obj) {
            if (obj.isVisible) {
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, obj.textureID);
                glm::mat4 model = glm::translate(glm::mat4(1.0f), obj.position);
                model = glm::scale(model, glm::vec3(obj.size * obj.aspectRatio, obj.size, 1.0f));
                glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, glm::value_ptr(model));
                glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
            }
        };
        
        // ��Ⱦ��������
        renderObject(background);
        renderObject(dog);
        for (const auto& cookie : cookies) {
            renderObject(cookie);
        }

        // --- ImGui ��Ⱦ ---
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();
        ImGui::Begin("Inspector");
        ImGui::Text("Dog Control");
        ImGui::DragFloat3("Position", &dog.position.x, 0.1f);
        ImGui::SliderFloat("Size", &dog.size, 0.5f, 5.0f);
        ImGui::Separator();
        ImGui::Text("Scene Control");
        ImGui::DragFloat3("Cam Position", &cam_position.x, 0.1f);
        ImGui::SliderFloat("Ambient", &ambientIntensity, 0.1f, 1.0f);
        ImGui::End();
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(window);
    }

    // --- ���� ---
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);
    glDeleteProgram(shaderProgram);
    glfwTerminate();

    return 0;
}